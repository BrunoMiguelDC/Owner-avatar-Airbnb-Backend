package scc.functions;

import com.azure.core.util.BinaryData;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobContainerClientBuilder;
import com.microsoft.azure.functions.annotation.*;

import com.microsoft.azure.functions.*;
import scc.mgt.AzureProperties;
import scc.utils.Hash;

/**
 * Azure Functions with Blob Trigger.
 */
public class BlobReplication
{

	private void replicateBlob(String containerName, String prefix, byte[] content){
		int numReplicas = Integer.parseInt(System.getenv(AzureProperties.NUM_REPLICAS));

		for(int i = 1; i <= numReplicas; i++){
			BlobContainerClient userBlobContainer = new BlobContainerClientBuilder()
					.connectionString(System.getenv(AzureProperties.BLOB_REPLICA_KEY+i))
					.containerName(containerName)
					.buildClient();
			String id = prefix + Hash.of(content);
			var blob = userBlobContainer.getBlobClient(id);
			blob.upload(BinaryData.fromBytes(content), true);
		}
	}

	@FunctionName("userBlobReplication")
	public void userBlobReplication(@BlobTrigger(name = "userBlobReplication",
									dataType = "binary",
									path = "users",
									connection = "BlobStoreConnection") byte[] content,
								final ExecutionContext context) {
		replicateBlob(AzureProperties.USER_BLOB_CONTAINER_NAME, "user-", content);
	}

	@FunctionName("houseBlobReplication")
	public void houseBlobReplication(@BlobTrigger(name = "houseBlobReplication",
			dataType = "binary",
			path = "houses",
			connection = "BlobStoreConnection") byte[] content,
									final ExecutionContext context) {
		replicateBlob(AzureProperties.HOUSE_BLOB_CONTAINER_NAME, "house-", content);
	}

}
