package scc.functions;

import java.util.*;
import java.util.stream.Collectors;

import com.azure.cosmos.CosmosClient;
import com.azure.cosmos.CosmosClientBuilder;
import com.azure.cosmos.models.CosmosQueryRequestOptions;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.functions.annotation.*;

import com.microsoft.azure.functions.*;
import scc.mgt.AzureProperties;

/**
 * Azure Functions with HTTP Trigger. These functions can be accessed at:
 * {Server_URL}/api/{route}
 * Complete URL appear when deploying functions.
 */
public class MostViewedHouses {

	private static class HouseViews{

		String id;
		long views;

		public HouseViews(String houseId, long count) {
			this.id = houseId;
			this.views = count;
		}

		public HouseViews(){}

		public String getId() {
			return id;
		}

		public long getViews() {
			return views;
		}

	}

	@FunctionName("mostViewedHouses")
	public HttpResponseMessage mostViewedHouses(@HttpTrigger(name = "req",
									methods = {HttpMethod.GET },
									authLevel = AuthorizationLevel.ANONYMOUS,
									route = "mostViewedHouses")
												HttpRequestMessage<Optional<String>> request,
												final ExecutionContext context){

		context.getLogger().info("Connecting to database");
		String[] connectionStr = System.getenv("AzureCosmosDBConnection").split(";");
		String endpoint = connectionStr[0].split("=")[1];

		String key = connectionStr[1].split("=", 2)[1];

		context.getLogger().info("Getting most viewed houses");

		try (CosmosClient cosmosClient = new CosmosClientBuilder()
				.endpoint(endpoint)
				.key(key)
				.directMode()
				.connectionSharingAcrossClientsEnabled(true)
				.contentResponseOnWriteEnabled(true)
				.buildClient()) {
			var houses = cosmosClient.getDatabase(AzureProperties.COSMOSDB_DATABASE).getContainer(AzureProperties.HOUSE_COSMOSDB_CONTAINER_NAME);
			var mostViewedHouses = houses.queryItems(
					"SELECT houses.id, houses.views FROM houses ORDER BY houses.views DESC OFFSET 0 LIMIT 10",
					new CosmosQueryRequestOptions(),
					HouseViews.class
			).stream().collect(Collectors.toList());
			if(mostViewedHouses.isEmpty())
				return request.createResponseBuilder(HttpStatus.OK).body("No houses in database").build();

			return request.createResponseBuilder(HttpStatus.OK)
					.header("Content-Type", "application/json")
					.body(new ObjectMapper().writeValueAsString(mostViewedHouses))
					.build();
		} catch (Exception e) {
            return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).body("EXCEPTION").build();
        }
    }

}
