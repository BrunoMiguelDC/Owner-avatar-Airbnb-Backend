package scc.functions;

import com.azure.cosmos.CosmosClient;
import com.azure.cosmos.CosmosClientBuilder;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobContainerClientBuilder;
import com.microsoft.azure.functions.annotation.*;

import redis.clients.jedis.Jedis;
import scc.cache.RedisCache;
import com.microsoft.azure.functions.*;
import scc.mgt.AzureProperties;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Azure Functions with Timer Trigger.
 */
public class RecentAddedHouses {
    @FunctionName("recentAddedHouses")
    public void updateMostRecentAddedHouses(@CosmosDBTrigger(name = "recentAddedHouses",
    										databaseName = AzureProperties.COSMOSDB_DATABASE,
    										collectionName = "houses",
    										preferredLocations="West Europe",
    										createLeaseCollectionIfNotExists = true,
    										connectionStringSetting = "AzureCosmosDBConnection")
        							String[] houses,
        							final ExecutionContext context ) {

		try (Jedis jedis = RedisCache.getCachePool().getResource()) {
			jedis.incr("cnt:houses");
			for( String h : houses) {
				jedis.lpush("recent::added::houses", h);
			}
			jedis.ltrim("recent::added::houses", 0, 9);
		}
    }

}
